# GeoFront（几何阵线）— 项目指南

## 这是什么？

一个用 Java Swing 写的 **2D 塔防游戏**。敌人沿固定路径走，你在空地上放不同形状的防御塔打它们，保护终点的能源核心。纯标准库实现，没有第三方依赖。

## 项目结构

```
src/
├── Main.java                    ← 程序入口
├── config/
│   └── GameConfig.java          ← 全局常量（窗口大小、颜色、升级参数等）
├── engine/
│   ├── GameEngine.java          ← 游戏引擎（核心逻辑，最重要的文件）
│   └── LevelManager.java        ← 关卡管理器（保存/加载自定义关卡文件）
├── model/
│   ├── GameState.java           ← 游戏状态枚举（菜单/准备/战斗/暂停/胜/负）
│   ├── TowerType.java           ← 塔类型（类注册表，4种默认 + 自定义）
│   ├── EnemyType.java           ← 敌人类型（类注册表，4种默认 + 自定义）
│   ├── LevelDef.java            ← 关卡定义（可变数据，用于关卡编辑器）
│   ├── WaveDef.java             ← 波次定义（可变数据，用于关卡编辑器）
│   ├── Tower.java               ← 防御塔（找目标、攻击、升级）
│   ├── Enemy.java               ← 敌人（沿路径移动、受伤、减速）
│   ├── EnergyCore.java          ← 能源核心（HP + 能源资源）
│   ├── GameMap.java             ← 网格地图（20×15格子，路径/空地/障碍）
│   ├── Wave.java                ← 波次（按间隔生成一串敌人）
│   └── LevelData.java           ← 预置关卡数据（地图布局 + 5波敌人配置）
└── ui/
    ├── GameFrame.java           ← 主窗口（组装面板，CardLayout 切换）
    ├── MenuPanel.java           ← 主菜单（含主菜单/模式选择/关卡选择/设置入口）
    ├── SettingsPanel.java       ← 设置面板（4个标签页：游戏/关卡编辑/敌人/塔）
    ├── GamePanel.java           ← 游戏画面（画格子、塔、敌人，处理鼠标）
    ├── HUDPanel.java            ← 信息栏（血量/能源/选塔/升级按钮）
    └── ShapeRenderer.java       ← 绘图工具（画三角形/方形/菱形/六边形等）
```

## 游戏是怎么跑起来的（核心流程）

```
Main.main()
  → GameFrame（创建窗口）
    → MenuPanel（显示主菜单）
    → 玩家选关开始 → 创建 GameEngine
    → startGameLoop() 启动 Swing Timer
      └── 每 ~16ms（60帧）执行一次：
          1. engine.update()      — 更新游戏逻辑
          2. hudPanel.updateInfo() — 刷新界面数据
          3. gamePanel.repaint()   — 重绘画面
```

### GameEngine.update() 每帧做的事（按顺序）

```
1. 能源产出     → 每秒 +2 能源
2. 波次准备     → 倒计时（10秒）期间不刷怪，让玩家放塔
3. 生成敌人     → Wave 按间隔把敌人加入列表
4. 移动敌人     → 每个 Enemy 沿路径像素级移动
5. 塔攻击       → 每个 Tower 找射程内最远的敌人打
6. 清理死亡敌人 → 移除尸体，发放击杀奖励
7. 攻击特效     → 画攻击线条动画
8. 检查胜负     → 核心HP=0输，全部波次打完赢
```

## 各类的职责

### config/GameConfig — "游戏配置表"
所有魔法数字集中在这里。改一个值，全局生效。比如：
- `CELL_SIZE = 40` → 每格40像素
- `FPS = 60` → 每秒60帧
- `MAX_LEVEL = 7` → 塔最高7级
- `UPGRADE_COST_MULTIPLIER = 1.8` → 每级升级费×1.8
- 还包含运行时可调的设置：网格线显示、敌人血条、FPS、音量、难度

### model/GameMap — "地图"
- 20列×15行的 `int[][]` 网格
- 0=空地(可放塔), 1=路径(敌人走), 2=障碍, 3=核心
- `canPlaceTower(col, row)` 检查能否放塔
- 路径被自动提取成 `List<Point>` 供敌人行走

### model/Enemy — "一个敌人"
- 按路径点列表移动，用像素坐标（不是格子坐标）
- `move()` 方法：每帧计算方向，移动 speed 个像素
- `pathIndex` 追踪走到了第几个路径点
- 支持减速效果（减速倍率 + 持续时间）

### model/Tower — "一座塔"
- `findTarget()` → 在射程内找 pathIndex 最大的敌人（经典策略：打最远的）
- `tryAttack()` → 检查冷却，找到目标就造成伤害
- `upgrade()` → 提升等级，按公式重算伤害/射程/冷却
- 能源塔(ENERGY)不攻击，是经济建筑
- `removeTower()` → 拆除返还部分能源
- 塔类型可动态扩展（见 TowerType 部分）

### model/TowerType — "塔类型注册表"
- 不再是枚举，而是**类 + 静态常量 + 注册表**模式
- 4种默认类型：ARROW（箭塔△）、CANNON（炮塔□）、SLOW（减速塔◇）、ENERGY（能源塔⬡）
- 通过 `TowerType.getAll()` 获取全部类型（含自定义）
- 支持在设置面板中动态添加/删除自定义塔类型
- 升级费用公式：`baseCost × 1.8^(level-1)`（0级→1级费用为 baseCost）

### model/EnemyType — "敌人类型注册表"
- 同样是**类 + 注册表**模式，支持动态增删
- 4种默认类型：INFANTRY（步兵●）、HEAVY（重装兵■）、FAST（快速兵○）、SUICIDE（自爆兵✦）
- 可通过设置面板修改属性或添加自定义敌人类型
- 默认类型不可删除（`removeCustom()` 保护）

### model/Wave — "一波敌人"
- 内部有一个敌人类型队列
- `update()` 每帧检查：到了间隔就生成下一个敌人
- `isAllSpawned()` → 判断这波是否刷完
- 支持难度系数递增：`难度倍率 + 当前波次索引 × 0.1`

### model/LevelDef / WaveDef — "关卡和波次的可变定义"
- LevelDef 包含地图数据、路径列表、波次定义列表
- 实现了 `Serializable`，可通过 LevelManager 保存/加载
- WaveDef 是 Wave 的可编辑版本，存储敌人类型列表和生成间隔
- `toWave()` 将定义转换为运行时 Wave 对象
- 关卡编辑器直接修改 LevelDef 实例

### engine/GameEngine — "总指挥"
- 持有所有游戏对象：地图、塔列表、敌人列表、波次列表
- 通过静态字段 `currentLevelDef` 加载关卡数据（编辑器也是改这个）
- 对外提供操作：`placeTower()`, `upgradeTower()`, `removeTower()`, `getTowerAt()`
- 内部类 `AttackEffect` 存储攻击特效数据

### engine/LevelManager — "关卡文件管理器"
- 使用 Java 序列化将自定义关卡保存到 `levels/` 目录的 `.dat` 文件
- `save(name, levelDef)` → 保存关卡
- `load(file)` → 加载关卡
- `listLevels()` → 列出所有已保存的关卡
- 文件名做安全处理（特殊字符替换为下划线）

### ui/MenuPanel — "主菜单面板"
- 用 CardLayout 切换：主菜单屏 → 模式选择屏 → 关卡选择屏
- 主菜单：开始游戏 / 设置 / 退出
- 模式选择：关卡模式 / 联机模式（禁用，标注"即将推出"）/ 返回
- 关卡选择：默认"S形路径"关卡 + 动态读取的自定义关卡列表
- 深色渐变背景，可选背景图覆盖
- 设置入口直接切换到 SettingsPanel

### ui/SettingsPanel — "设置面板（4个标签页）"
| 标签页 | 功能 |
|--------|------|
| 游戏设置 | 网格线/敌人血条/FPS 开关、音量滑块、难度选择（简单/普通/困难） |
| 关卡编辑 | 20×15 网格画笔工具（空地/路径/障碍/核心）+ 波次编辑器（增删敌人、改间隔）+ 保存/加载/清空 |
| 敌人配置 | 表格展示所有敌人类型，可修改属性、添加/删除自定义类型 |
| 防御设置 | 表格展示所有塔类型，可修改属性、添加/删除自定义类型 |

- 关卡编辑器中点击格子绘制地图，自动重建路径点
- 波次编辑器支持添加/删除敌人、调整生成间隔

### ui/GamePanel — "画面渲染"
- `paintComponent()` 里画一切：格子、路径、塔、敌人、特效、鼠标预览
- 鼠标点击 → 放塔/选塔；鼠标移动 → 显示放置预览
- 调用 `ShapeRenderer` 画各种几何形状
- 选中塔后显示射程范围圆圈

### ui/HUDPanel — "右侧信息栏"
- 显示血量、能源、波次进度
- 4个选塔按钮（点击设置 engine.selectedTowerType）
- 选中塔的信息面板 + 升级按钮
- 拆除按钮（返还部分能源）

## 游戏界面结构

```
GameFrame（主窗口，CardLayout 切换）
├── "menu" 卡片 → MenuPanel
│     ├── 主菜单屏：开始游戏 / 设置 / 退出
│     ├── 模式选择屏：关卡模式 / 联机模式(禁用) / 返回
│     ├── 关卡选择屏：默认关卡 + 自定义关卡列表
│     └── 设置面板（嵌入 SettingsPanel，4个标签页）
│
└── "game" 卡片 → JPanel(BorderLayout)
      ├── CENTER → GamePanel（800×600 游戏画布）
      │     ├── ESC 暂停/恢复
      │     ├── Q 返回菜单（暂停/结束时）
      │     └── 鼠标：放塔/选塔/预览/拆除
      └── EAST → HUDPanel（266px 侧边栏）
            ├── 能源/血量/波次信息
            ├── 4个选塔按钮
            └── 选中塔信息 + 升级/拆除按钮
```

## 设置面板详解

### 游戏设置
- **显示网格线**：切换游戏画面中的网格线
- **显示敌人血条**：在敌人头顶显示HP条
- **显示 FPS**：右上角显示实时帧率
- **音量**：0~100 滑块（预留音频接口）
- **游戏难度**：简单（敌人属性×0.7）/ 普通（×1.0）/ 困难（×1.3）

### 关卡编辑
点击格子选择画笔模式（空地/路径/障碍/核心），在20×15网格上绘制地图。右侧配置波次——添加/删除敌人类型、调整生成间隔。支持保存到本地文件和加载已保存的关卡。

### 敌人配置 / 防御设置
表格展示所有类型的属性，双击单元格直接修改数值。点击"添加新敌人/新塔"创建自定义类型，支持动态删除自定义条目。默认类型受保护不可删除。

## Java 知识点速查

### 这个项目用到的核心概念

| 概念 | 在项目中怎么用的 |
|------|------------------|
| **类和对象** | Tower、Enemy 都是类，每个实例就是一个塔/敌人 |
| **静态常量 + 注册表** | TowerType、EnemyType — 类替代枚举，支持动态增删 |
| **集合(List)** | `List<Tower> towers` 存所有塔，`List<Enemy> enemies` 存所有敌人 |
| **继承** | GameFrame extends JFrame, MenuPanel extends JPanel |
| **内部类** | GameEngine.AttackEffect 是内部类 |
| **static方法** | LevelData、LevelManager 的方法都是 static |
| **序列化** | LevelDef/WaveDef/TowerType/EnemyType 实现 Serializable |
| **Timer** | Swing Timer 每16ms触发一次 → 驱动游戏循环 |
| **事件监听** | MouseListener/MouseMotionListener 处理鼠标操作 |
| **paintComponent** | 重写 JPanel 的这个方法来画自定义图形 |
| **Iterator** | cleanupDeadEnemies() 用 Iterator 安全删除列表元素 |
| **CardLayout** | GameFrame / MenuPanel / SettingsPanel 中切换子面板 |
| **GridBagLayout** | 菜单和设置界面排版 |

### 重要区分：格子坐标 vs 像素坐标

```
格子坐标 (col, row)     像素坐标 (x, y)
  → 用于地图逻辑          → 用于画面渲染
  → 范围: 0~19, 0~14     → 范围: 0~800, 0~600
  → 转换: pixelX = col * CELL_SIZE + CELL_SIZE/2
```

## 后续加功能的切入点

### 加新关卡（方法一：在 LevelData 里加）
1. 在 `LevelData.java` 新增三个 static 方法（地图布局、路径、波次配置），格式和关卡1一样
2. 在 `GameEngine` 构造函数里加 switch case
3. 在关卡选择屏加对应按钮

### 加新关卡（方法二：用关卡编辑器）
直接运行游戏，进入 **设置 > 关卡编辑**，用鼠标绘制地图、配置波次，保存到本地文件。下次启动时自定义关卡会显示在关卡选择列表中。

### 加新敌人类型
在设置面板的 **敌人配置** 标签页中点击"添加新敌人"，或代码中直接 `new EnemyType(name, hp, speed, damage, reward, symbol)` 即可自动注册。

### 加新塔类型
在设置面板的 **防御设置** 标签页中点击"添加新塔"，或代码中直接 `new TowerType(name, cost, damage, range, cooldown, symbol)` 即可自动注册。然后在 `ShapeRenderer` 里画它的形状。

## 编译和运行

```bash
# 从项目根目录编译
javac -sourcepath src src/Main.java

# 运行
java -cp src Main
```

