NoteForge 导出文件
====================

导出时间：2026/9/19 23:48:19

目录结构：
  noteforge.json        配置与元数据
  notes/<科目>/<标题>.md  纯 Markdown 笔记
  assets/<id>.<ext>     图片等附件
  README.txt            本文件

notes/ 下的 .md 是纯 Markdown，可用任何编辑器打开。
图片以相对路径 ../../assets/ 引用。

导入时请使用未解压的 zip 文件（可被 7-Zip / WinRAR 重打包，
但请勿修改内部目录结构）。
